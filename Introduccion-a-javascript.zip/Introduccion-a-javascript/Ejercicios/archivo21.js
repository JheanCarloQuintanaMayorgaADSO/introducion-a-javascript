/*21.  Escribir un programa que calcule el volumen de un elipsoide. */
function calcularVolumenElipsoide(a, b, c) {
  return (4/3) * Math.PI * a * b * c;
}