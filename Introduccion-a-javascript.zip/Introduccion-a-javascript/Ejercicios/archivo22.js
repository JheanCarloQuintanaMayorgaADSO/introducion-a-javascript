/* 22. Escribir un programa que muestre el pago de una llamada telefónica sabiendo que cada
minuto cuesta $355 pesos y un IVA 20%.*/